﻿namespace WhiteBinTools.UnpackClasses
{
    public partial class UnpackProcess
    {
        public string WhiteBinName;
        public string InBinFileDir;
        public string ExtractDirName;
        public string ExtractDir;

        public int CountDuplicates;
        public string UnpackedState;
    }
}