﻿namespace WhiteBinTools.SupportClasses
{
    public class CmnEnums
    {
        public enum GameCodes
        {
            ff131,
            ff132,
            none
        }


        public enum Endianness
        {
            LittleEndian,
            BigEndian
        }
    }
}